﻿using System.Reflection;

[assembly: AssemblyTitle("WeCantSpell.Hunspell.Performance.Comparison")]
[assembly: AssemblyDescription("")]
