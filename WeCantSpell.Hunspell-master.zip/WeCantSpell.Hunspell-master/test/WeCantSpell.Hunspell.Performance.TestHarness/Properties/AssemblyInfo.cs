﻿using System.Reflection;

[assembly: AssemblyTitle("WeCantSpell.Hunspell.Performance.TestHarness")]
[assembly: AssemblyDescription("")]