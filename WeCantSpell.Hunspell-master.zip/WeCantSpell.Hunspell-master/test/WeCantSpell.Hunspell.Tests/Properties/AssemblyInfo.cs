﻿using System.Reflection;

[assembly: AssemblyTitle("WeCantSpell.Hunspell.Tests")]
[assembly: AssemblyDescription("")]
